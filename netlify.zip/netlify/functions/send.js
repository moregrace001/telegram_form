const https = require("https");

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    const name = body.name;
    const email = body.email;
    const message = body.message;

    const botToken = "8845176480:AAGWb-uDugzZts6feQIr8no2X2IT49LIWzw";
    const chatId = "7185234673";

    const text = `
📩 New Form Submission:

👤 Name: ${name}
📧 Email: ${email}
💬 Message: ${message}
`;

    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

    const data = JSON.stringify({
      chat_id: chatId,
      text: text
    });

    await new Promise((resolve, reject) => {
      const req = https.request(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": data.length
        }
      }, (res) => {
        let response = "";

        res.on("data", (chunk) => {
          response += chunk;
        });

        res.on("end", () => {
          console.log("Telegram response:", response);
          resolve();
        });
      });

      req.on("error", reject);
      req.write(data);
      req.end();
    });

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ success: true })
    };

  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};